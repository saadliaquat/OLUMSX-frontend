import { Fragment, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { Disclosure, Menu, Transition, Popover } from '@headlessui/react'
import {
    Bars3Icon, XMarkIcon, ShoppingCartIcon, HeartIcon, DevicePhoneMobileIcon,
    ComputerDesktopIcon,
    CodeBracketIcon,
    ShoppingBagIcon,
    HomeIcon,
    SparklesIcon,
    BookOpenIcon,
    PuzzlePieceIcon,
    LifebuoyIcon,
    CakeIcon,
    MagnifyingGlassIcon
} from '@heroicons/react/24/outline'
import { ChevronDownIcon } from '@heroicons/react/20/solid'

import "../../styles/Navbar.css"

import logo from "../../assets/olumsX-transparent.png";

let navigation = []

const categories = [
    { name: 'Mobile Phones', href: '/categorysearch/mobilephones', icon: DevicePhoneMobileIcon },
    { name: 'Laptops and Computers', href: '/categorysearch/laptopsandcomputers', icon: ComputerDesktopIcon },
    { name: 'Tech Accessories', href: '/categorysearch/techaccessories', icon: CodeBracketIcon },
    { name: 'Fashion', href: '/categorysearch/fashion', icon: ShoppingBagIcon },
    { name: 'Home and Decor', href: '/categorysearch/homeanddecor', icon: HomeIcon },
    { name: 'Beauty and Health', href: '/categorysearch/beautyandhealth', icon: SparklesIcon },
    { name: 'Books', href: '/categorysearch/books', icon: BookOpenIcon },
    { name: 'Toys and Games', href: '/categorysearch/toysandgames', icon: PuzzlePieceIcon },
    { name: 'Sports and Outdoors', href: '/categorysearch/sportsandoutdoors', icon: LifebuoyIcon },
    { name: 'Food and Grocery', href: '/categorysearch/foodandgrocery', icon: CakeIcon },
];

function classNames(...classes) {
    return classes.filter(Boolean).join(' ')
}

export default function Header1({ currentPage }) {
    const [searchTerm, setSearchTerm] = useState('');

    const handleSearch = async () => {

        if (searchTerm.trim()) {
            navigate(`/search/${searchTerm}`);
        } else {
            console.log('Please enter a search term.');
        }
    };

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            handleSearch();
        }
    };

    navigation = navigation.map((item) => ({
        ...item,
        current: item.name === currentPage,
    }));

    const userID = localStorage.getItem("userId");
    const [userName, setUserName] = useState('');

    useEffect(() => {
        const getUserDetails = async () => {
            try {
                const response = await fetch('https://olumsx-backend-deploy-new.vercel.app/api/user/getuserbyid', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ UserID: userID })
                });

                if (!response.ok) {
                    throw new Error('Error');
                }

                const data = await response.json();
                setUserName(data.username);

            } catch (error) {
                console.error('Error fetching user details:', error);
            }
        };

        getUserDetails();
    }, [userID]);

    const getInitials = (name) => {
        return name.split(' ').map((n) => n[0]).join('').toUpperCase();
    };

    const navigate = useNavigate();

    const goToWishlist = () => {
        navigate('/wishlist');
    };

    const goToCart = () => {
        navigate('/cart');
    };

    return (
        <Disclosure as="nav" className="bg-black py-1">
            {({ open }) => (
                <>
                    <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
                        <div className="relative flex h-16 items-center justify-between">

                            {/* Mobile menu button*/}
                            <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
                                <Disclosure.Button className="relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                                    <span className="absolute -inset-0.5" />
                                    <span className="sr-only">Open main menu</span>
                                    {open ? (
                                        <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
                                    ) : (
                                        <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
                                    )}
                                </Disclosure.Button>
                            </div>

                            {/* Left Side - Navbar */}
                            <div className="flex items-center justify-center sm:items-stretch sm:justify-start">
                                {/* Logo */}
                                <div className="flex flex-shrink-0 items-center navbar-logo">
                                    <a href="/">
                                        <img src={logo} alt="logo" style={{ width: '100px', height: 'auto' }} />
                                    </a>
                                </div>
                            </div>

                            <Popover className="relative">
                                <Popover.Button className="flex items-center gap-x-1 text-sm font-semibold leading-6 text-white focus:outline-none pt-1">
                                    Categories
                                    <ChevronDownIcon className="h-5 w-5 flex-none text-gray-400" aria-hidden="true" />
                                </Popover.Button>

                                <Transition
                                    as={Fragment}
                                    enter="transition ease-out duration-200"
                                    enterFrom="opacity-0 translate-y-1"
                                    enterTo="opacity-100 translate-y-0"
                                    leave="transition ease-in duration-150"
                                    leaveFrom="opacity-100 translate-y-0"
                                    leaveTo="opacity-0 translate-y-1"
                                >
                                    <Popover.Panel className="absolute -left-8 top-full z-10 mt-3 w-72 overflow-hidden rounded-3xl bg-white shadow-lg ring-1 ring-gray-900/5">
                                        <div className="p-3">
                                            {categories.map((item) => (
                                                <div
                                                    key={item.name}
                                                    className="group relative flex items-center gap-x-4 rounded-lg p-1 text-sm leading-6 hover:bg-gray-50"
                                                >
                                                    <div className="flex h-11 w-11 flex-none items-center justify-center rounded-lg bg-gray-50 group-hover:bg-white">
                                                        <item.icon className="h-6 w-6 text-gray-600 group-hover:text-indigo-600" aria-hidden="true" />
                                                    </div>
                                                    <div className="flex-auto">
                                                        <a href={item.href} className="block font-semibold text-gray-900">
                                                            {item.name}
                                                            <span className="absolute inset-0" />
                                                        </a>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </Popover.Panel>
                                </Transition>
                            </Popover>

                            {/* Search Bar */}
                            <div className="flex items-center bg-white rounded-full w-1/2 text-sm px-1 focus-within:outline-blue">
                                <input
                                    type="text"
                                    className="w-full rounded-full py-2.5 px-4 text-gray-700 leading-tight focus-outline-none text-sm border-0"
                                    placeholder="Search..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    onKeyDown={handleKeyDown}
                                />
                                <button
                                    className="p-2 rounded-full text-gray-500 hover:text-gray-700 focus:outline-none"
                                    onClick={handleSearch}
                                >
                                    <MagnifyingGlassIcon className="h-4 w-4" aria-hidden="true" />
                                </button>
                            </div>


                            {/* Right Side - Navbar */}
                            <div className="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">
                                {/* Wishlist Icon */}
                                <div className="relative group">
                                    <button
                                        type="button"
                                        onClick={goToWishlist}
                                        className="rounded-full p-1 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800"
                                    >
                                        <HeartIcon className="h-6 w-6" aria-hidden="true" />
                                    </button>
                                    <span className="absolute transform -translate-x-1/2 -translate-y-1/2 mt-2 hidden group-hover:block px-2 py-1 bg-black text-white text-xs rounded">
                                        Wishlist
                                    </span>
                                </div>

                                {/* Cart Icon */}
                                <div className="relative group">
                                    <button
                                        type="button"
                                        onClick={goToCart}
                                        className="rounded-full p-1 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800"
                                    >
                                        <ShoppingCartIcon className="h-6 w-6" aria-hidden="true" />
                                    </button>
                                    <span className="absolute transform -translate-x-1/4 -translate-y-1/2 mt-2 hidden group-hover:block px-2 bg-black text-white text-xs rounded">
                                        Cart
                                    </span>
                                </div>

                                {/* Profile Dropdown */}
                                <Menu as="div" className="relative ml-3">
                                    <div>
                                        <Menu.Button className="relative flex rounded-full bg-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800">
                                            <span className="absolute -inset-1.5" />
                                            <span className="sr-only">Open user menu</span>
                                            <span className="h-8 w-8 rounded-full flex items-center justify-center font-semibold text-black">
                                                {getInitials(userName)}
                                            </span>
                                        </Menu.Button>
                                    </div>
                                    <Transition
                                        as={Fragment}
                                        enter="transition ease-out duration-100"
                                        enterFrom="transform opacity-0 scale-95"
                                        enterTo="transform opacity-100 scale-100"
                                        leave="transition ease-in duration-75"
                                        leaveFrom="transform opacity-100 scale-100"
                                        leaveTo="transform opacity-0 scale-95"
                                    >
                                        <Menu.Items className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="/profile"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Your Profile
                                                    </a>
                                                )}
                                            </Menu.Item>

                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="/customerorders"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Your Orders
                                                    </a>
                                                )}
                                            </Menu.Item>

                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="/chatcustomer"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Your Chats
                                                    </a>
                                                )}
                                            </Menu.Item>

                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                    href="/"
                                                    className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    onClick={(e) => {
                                                        console.log("pfft ", localStorage.getItem("user_id"))
                                                        e.preventDefault();
                                                        fetch(`https://olumsx-backend-deploy-new.vercel.app/api/session/deletesession`, {
                                                            method: 'POST',
                                                            headers: {
                                                                'Content-Type': 'application/json'
                                                            },
                                                            body: JSON.stringify({userID: localStorage.getItem("user_id")}),
                                                        });

                                                        alert("BYE!")
                                                        localStorage.clear();
                                                        window.location.href = 'http://localhost:3000';
                                                    }}
                                                    >
                                                        Sign out
                                                    </a>
                                                )}
                                            </Menu.Item>

                                        </Menu.Items>
                                    </Transition>
                                </Menu>
                            </div>
                        </div>

                    </div>

                    <Disclosure.Panel className="sm:hidden">
                        <div className="space-y-1 px-2 pb-3 pt-2">
                            {navigation.map((item) => (
                                <Disclosure.Button
                                    key={item.name}
                                    as="a"
                                    href={item.href}
                                    className={classNames(
                                        item.current ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white',
                                        'block rounded-md px-3 py-2 text-base font-medium'
                                    )}
                                    aria-current={item.current ? 'page' : undefined}
                                >
                                    {item.name}
                                </Disclosure.Button>
                            ))}
                        </div>
                    </Disclosure.Panel>
                </>
            )}
        </Disclosure>
    )
}